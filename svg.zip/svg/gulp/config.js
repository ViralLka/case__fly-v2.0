'use strict';
var path = require('path');

// Default paths
var app = 'app';

// Default paths in app folder
var images = 'images';
var sprites = 'sprites';


// Images task config
module.exports.sprites = {
  src: path.join(app, sprites, '/*'),
  svg: path.join(images, '/svg/sprite.svg'),
  dest: path.join(app, '/')
};
